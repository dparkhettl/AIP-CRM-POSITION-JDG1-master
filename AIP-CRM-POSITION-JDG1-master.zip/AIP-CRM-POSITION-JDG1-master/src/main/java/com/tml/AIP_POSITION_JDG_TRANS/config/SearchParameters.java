package com.tml.AIP_POSITION_JDG_TRANS.config;

public enum SearchParameters {
	
	//POSTN_ROWID("postn_rowid");
	ORG_ID("org_id");
	
	String value;

    public String getValue() {
        return value;
    }

    SearchParameters(String value) {
        this.value = value;
    }

}

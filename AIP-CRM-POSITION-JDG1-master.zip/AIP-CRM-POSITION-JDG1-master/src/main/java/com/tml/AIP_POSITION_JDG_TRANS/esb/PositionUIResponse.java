package com.tml.AIP_POSITION_JDG_TRANS.esb;

import org.infinispan.protostream.annotations.ProtoDoc;
import org.infinispan.protostream.annotations.ProtoField;

import com.fasterxml.jackson.annotation.JsonFormat;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.TimeZone;


@JsonPropertyOrder({"DIV_NAME"})
//@JsonPropertyOrder({"POSTN_ROWID"})

//@XmlType(propOrder = {"div_name"}) 
@XmlAccessorType(XmlAccessType.FIELD)

@JsonIgnoreProperties(ignoreUnknown = true)
@XmlRootElement(name = "PositionUI_APIResponse")

public class PositionUIResponse {
	
	@XmlElement(name = "POSTN_ROWID")
	@JsonProperty("POSTN_ROWID")
    private String postn_rowid;
	
	@XmlElement(name = "POSTN_NAME")
	@JsonProperty("POSTN_NAME")
	private String postn_name;

	@XmlElement(name = "POSTN_TYPE_CD")
	@JsonProperty("POSTN_TYPE_CD")
    private String postn_type_cd;
	
	@XmlElement(name = "DIV_ROWID")
	@JsonProperty("DIV_ROWID")
    private String div_rowid;
	
	@XmlElement(name = "X_PROD_LN_ID")
	@JsonProperty("X_PROD_LN_ID")
    private String x_prod_ln_id;
	
	@XmlElement(name = "DIV_NAME")
	@JsonProperty("DIV_NAME")
    private String div_name;
	
	
	@XmlElement(name = "ORG_NAME")
	@JsonProperty("ORG_NAME")
    private String org_name;
	
	@XmlElement(name = "ORG_ID")
	@JsonProperty("ORG_ID")
    private String org_id;
	
	@XmlElement(name = "PARENT_POSTN_ID")
	@JsonProperty("PARENT_POSTN_ID")
    private String parent_postn_id;
	
	@XmlElement(name = "EMP_ID")
	@JsonProperty("EMP_ID")
    private String emp_id ;
	
	@XmlElement(name = "EMP_NAME")
	@JsonProperty("EMP_NAME")
    private String emp_name;
	
	@XmlElement(name = "CELL_PHONE")
	@JsonProperty("CELL_PHONE")
    private String cell_phone;
	
	@XmlElement(name = "EMAIL")
	@JsonProperty("EMAIL")
    private String email;
    
	
	@XmlElement(name = "LOGIN")
	@JsonProperty("LOGIN")
    private String login;
	
	
	
	 @XmlTransient
	    @JsonIgnore
	    private String rowId;
		
		@ProtoField(number = 1, required = false, defaultValue = "0")
		public String getPostn_rowid() {
			return postn_rowid;
		}

		public void setPostn_rowid(String postn_rowid) {
			this.postn_rowid = postn_rowid;
		}
	 
	 @ProtoField(number = 2, required = false , defaultValue = "0")
	 public String getPostn_name() {
			return postn_name;
		}

		public void setPostn_name(String postn_name) {
			this.postn_name = postn_name;
		}

		@ProtoField(number = 3, required = false, defaultValue = "0")
		public String getPostn_type_cd() {
			return postn_type_cd;
		}

		public void setPostn_type_cd(String postn_type_cd) {
			this.postn_type_cd = postn_type_cd;
		}

		@ProtoField(number = 4, required = false, defaultValue = "null")
		public String getDiv_rowid() {
			return div_rowid;
		}

		public void setDiv_rowid(String div_rowid) {
			this.div_rowid = div_rowid;
		}

		@ProtoField(number = 5, required = false, defaultValue = "0")
		public String getX_prod_ln_id() {
			return x_prod_ln_id;
		}

		public void setX_prod_ln_id(String x_prod_ln_id) {
			this.x_prod_ln_id = x_prod_ln_id;
		}

		
		 @ProtoField(number = 6, required = false, defaultValue = "null")
		public String getDiv_name() {
			return div_name;
		}

		public void setDiv_name(String div_name) {
			this.div_name = div_name;
		}
		
		 @ProtoField(number = 7, required = false, defaultValue = "null")
		public String getOrg_name() {
			return org_name;
		}

		public void setOrg_name(String org_name) {
			this.org_name = org_name;
		}
		
		@ProtoField(number = 8, required = false, defaultValue = "null")
		public String getOrg_id() {
			return org_id;
		}

		public void setOrg_id(String org_id) {
			this.org_id = org_id;
		}
		
		@ProtoField(number = 9, required = false, defaultValue = "null")
		public String getParent_postn_id() {
			return parent_postn_id;
		}

		public void setParent_postn_id(String parent_postn_id) {
			this.parent_postn_id = parent_postn_id;
		}
		
		@ProtoField(number = 10, required = false, defaultValue = "null")
		public String getEmp_id() {
			return emp_id;
		}

		public void setEmp_id(String emp_id) {
			this.emp_id = emp_id;
		}
		
		@ProtoField(number = 11, required = false, defaultValue = "null")
		public String getEmp_name() {
			return emp_name;
		}

		public void setEmp_name(String emp_name) {
			this.emp_name = emp_name;
		}
		
		@ProtoField(number = 12, required = false, defaultValue = "null")
		public String getCell_phone() {
			return cell_phone;
		}

		public void setCell_phone(String cell_phone) {
			this.cell_phone = cell_phone;
		}
		
		@ProtoField(number = 13, required = false, defaultValue = "null")
		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}
		
		@ProtoField(number = 14, required = false, defaultValue = "null")
		public String getLogin() {
			return login;
		}

		public void setLogin(String login) {
			this.login = login;
		}

		 @ProtoField(number = 15, required = false)
		public String getRowId() {
			return rowId;
		}

		public void setRowId(String rowId) {
			this.rowId = rowId;
		}    
   
	
}

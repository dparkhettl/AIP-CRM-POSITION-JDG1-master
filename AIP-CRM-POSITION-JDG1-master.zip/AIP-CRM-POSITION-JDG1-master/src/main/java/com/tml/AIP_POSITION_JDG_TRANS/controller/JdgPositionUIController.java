package com.tml.AIP_POSITION_JDG_TRANS.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tml.AIP_POSITION_JDG_TRANS.controller.JdgPositionUIController;
import com.tml.AIP_POSITION_JDG_TRANS.esb.PositionUIResponse;
import com.tml.AIP_POSITION_JDG_TRANS.service.JdgService;
import org.springframework.scheduling.annotation.Scheduled;

@RestController
@RequestMapping(path = "/api/crm")
public class JdgPositionUIController {

	private static Logger logger = LoggerFactory.getLogger(JdgPositionUIController.class);
	@Autowired
	JdgService jdgServiceImpl;
	
	
	
	  @CrossOrigin
	  
	  @PostMapping(path = "/all" , produces = MediaType.APPLICATION_JSON_VALUE )
	  public boolean putAll(@RequestParam("orderId")String orderId) throws
	  Exception { logger.info("Entering Method  JdgPositionUIController.putAll"); try {
	  
	  jdgServiceImpl.putAll(orderId);
	  
	  } catch (DateTimeParseException ex){ logger.
	  error("Exception occurred with while parsing Dates startDate {} and endDate {}"
	  , orderId); throw new
	  Exception("Exception occurred while parsing Dates : ",ex); } catch (Exception
	  e) { logger.error("Exception occurred with e {}", e); throw new
	  Exception("Exception occurred while processing : ",e); }
	  logger.info("Exiting Method  JdgPositionUIController.putAll"); return true; }
	 

	@CrossOrigin
	@GetMapping(path = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<PositionUIResponse> getData() throws Exception {
		logger.info("Entering Method  JdgPositionUIController.getData");
		List<PositionUIResponse> PositionUIList = null;
		try {
			
			PositionUIList = jdgServiceImpl.getAll();
		} catch (Exception e) {
			logger.error("Exception occurred with e {}", e);
			// throw new Exception("Exception occurred while processing : ",e);
		}
		logger.info("Exiting Method  JdgPositionUIController.getData");
		return PositionUIList;
	}



	
	  @CrossOrigin
    @PostMapping(path = "/delete" , produces = MediaType.APPLICATION_JSON_VALUE )
    public boolean delete(@RequestParam("orderId")String orderId) throws Exception {
        logger.info("Entering Method  JdgPositionUIController.delete");
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			  jdgServiceImpl.delete(orderId);

        }
        catch (DateTimeParseException ex){
            logger.error("Exception occurred with while parsing Dates startDate {} and endDate {}", orderId);
            throw new Exception("Exception occurred while parsing Dates : ",ex);
        }
        catch (Exception e) {
            logger.error("Exception occurred with e {}", e);
            throw new Exception("Exception occurred while processing : ",e);
        }
        logger.info("Exiting Method  JdgPositionUIController.delete");
        return true;
    }
	
	@CrossOrigin
   @PostMapping(path = "/deleteById" , produces = MediaType.APPLICATION_JSON_VALUE )
   public boolean deleteById(@RequestParam("postn_rowid")String postn_rowid) throws Exception {
       logger.info("Entering Method  JdgPositionUIController.deleteById");
       try {
               jdgServiceImpl.deleteById(postn_rowid);
       }
       catch (DateTimeParseException ex){
           logger.error("Exception occurred with while parsing Dates startDate {} and endDate {}", postn_rowid);
           throw new Exception("Exception occurred while parsing Dates : ",ex);
       }
       catch (Exception e) {
           logger.error("Exception occurred with e {}", e);
           throw new Exception("Exception occurred while processing : ",e);
       }
       logger.info("Exiting Method  JdgPositionUIController.deleteById");

       return true;
   }

    
    @CrossOrigin
    @PostMapping(path = "/search" , produces = MediaType.APPLICATION_JSON_VALUE )
   public Set<PositionUIResponse> search(@RequestBody HashMap<String, String> paramMap) throws Exception{
   // public Set<PositionUIResponse> search(@RequestParam("PAR_ROW_ID")String PAR_ROW_ID) throws Exception{

   //public Set<PositionUIResponse> search(@RequestBody String PAR_ROW_ID) throws Exception{
        /*logger.info("Entering Method  JdgPositionUIController.search");
        logger.info("Entering Method  JdgPositionUIController.search"+paramMap);
        logger.info("Entering Method  JdgPositionUIController.search"+paramMap.toString());
        logger.info("Entering Method  JdgPositionUIController.search"+paramMap.size());*/
        Set<PositionUIResponse> searchedList = null;
        try {
            searchedList = jdgServiceImpl.search(paramMap);
        }catch (DateTimeParseException ex){
            logger.error("Exception occurred with while parsing Dates startDate and endDate");
            throw new Exception("Exception occurred while parsing Dates : ",ex);
        }
        catch (Exception e) {
            logger.error("Exception occurred with e {}", e);
            throw new Exception("Exception occurred while processing : ",e);
        }
        logger.info("Exiting Method  JdgPositionUIController.search");
        return searchedList;

    }
    
   // @CrossOrigin

    @PostMapping(path = "/searchJdg" )
   public List<HashMap<String, Object>> searchJdg(@RequestBody HashMap<String, String> Mapparam) {

         logger.info("Entering Method  JdgPositionUIController.search");
        logger.info("Entering Method  JdgPositionUIController.search"+Mapparam.isEmpty());
        logger.info("Entering Method  JdgPositionUIController.search"+Mapparam.toString());

        logger.info("Entering Method  JdgPositionUIController.search"+Mapparam.size());
      //  Set<PositionUIResponse> searchedList = null;
        try {
          //  searchedList = jdgServiceImpl.search(PAR_ROW_ID);
        }catch (DateTimeParseException ex){
            logger.error("Exception occurred with while parsing Dates startDate and endDate");

            //throw new Exception("Exception occurred while parsing Dates : ",ex);
        }
        catch (Exception e) {
            logger.error("Exception occurred with e {}", e);
           // throw new Exception("Exception occurred while processing : ",e);
        }
        logger.info("Exiting Method  JdgPositionUIController.search");

        return null;
    }

@Scheduled(cron = "0 0 11 * * *")
// @Scheduled(cron = "*/60 * * * * *")
public boolean positionScheduler() throws Exception 
{
logger.info("Entering scheduler");
String orderId = "1";
try {
    System.out.println("=============scheduler called========");
    jdgServiceImpl.putAll(orderId);

} catch (DateTimeParseException ex) {
logger.error("Exception occurred with while parsing Dates startDate {} and endDate {}", orderId);
throw new Exception("Exception occurred while parsing Dates : ", ex);
} catch (Exception e) {
logger.error("Exception occurred with e {}", e);
throw new Exception("Exception occurred while processing : ", e);
}
logger.info("Exiting scheduler");
return true;
}
}

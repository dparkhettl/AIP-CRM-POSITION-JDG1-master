package com.tml.AIP_POSITION_JDG_TRANS.config;

public interface JdgConstants {
	
	 String CACHE_NAME = "POSITION_DSALCRM";

}
